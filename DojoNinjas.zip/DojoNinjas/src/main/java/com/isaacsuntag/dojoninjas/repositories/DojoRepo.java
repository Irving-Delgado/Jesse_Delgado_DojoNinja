package com.isaacsuntag.dojoninjas.repositories;

import org.springframework.data.repository.CrudRepository;

import com.isaacsuntag.dojoninjas.models.Dojo;

public interface DojoRepo extends CrudRepository <Dojo, Long> {

}
